"""
utils.py — HTTP utilities, User-Agent rotation, URL helpers, and shared helpers.
"""

import random
import time
import logging
from urllib.parse import urlparse, urljoin
from typing import Optional, Dict, Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("wp_scanner.utils")

# ─── User-Agent Pool ─────────────────────────────────────────────────────────

USER_AGENTS = [
    # Chrome on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    # Firefox on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.0; rv:120.0) "
    "Gecko/20100101 Firefox/120.0",
    # Safari on macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.1 Safari/605.1.15",
    # Edge on Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    # Chrome on Linux
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    # Googlebot (passive recon)
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
]


def get_random_ua() -> str:
    """Return a random User-Agent string from the pool."""
    return random.choice(USER_AGENTS)


# ─── HTTP Session Factory ─────────────────────────────────────────────────────

def build_session(timeout: int = 10, retries: int = 2,
                  verify_ssl: bool = False) -> requests.Session:
    """
    Build a requests Session with retry logic and sensible defaults.

    Args:
        timeout:    Default request timeout in seconds.
        retries:    Number of retries on connection errors.
        verify_ssl: Whether to verify SSL certificates.

    Returns:
        Configured requests.Session instance.
    """
    session = requests.Session()

    retry_strategy = Retry(
        total=retries,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET"],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    session.verify = verify_ssl
    session.headers.update({
        "User-Agent": get_random_ua(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
        "DNT": "1",
    })
    session.timeout = timeout
    return session


# ─── Safe Request Wrapper ─────────────────────────────────────────────────────

def safe_get(session: requests.Session, url: str,
             timeout: int = 10, rotate_ua: bool = True,
             allow_redirects: bool = True) -> Optional[requests.Response]:
    """
    Perform a GET request with full error handling.

    Returns the Response on success, None on any failure.
    """
    if rotate_ua:
        session.headers["User-Agent"] = get_random_ua()
    try:
        resp = session.get(url, timeout=timeout,
                           allow_redirects=allow_redirects)
        return resp
    except requests.exceptions.SSLError as e:
        logger.debug("SSL error for %s: %s", url, e)
    except requests.exceptions.ConnectionError as e:
        logger.debug("Connection error for %s: %s", url, e)
    except requests.exceptions.Timeout:
        logger.debug("Timeout for %s", url)
    except requests.exceptions.RequestException as e:
        logger.debug("Request error for %s: %s", url, e)
    return None


def safe_head(session: requests.Session, url: str,
              timeout: int = 8) -> Optional[requests.Response]:
    """Perform a HEAD request with full error handling."""
    try:
        resp = session.head(url, timeout=timeout, allow_redirects=True)
        return resp
    except requests.exceptions.RequestException as e:
        logger.debug("HEAD error for %s: %s", url, e)
    return None


# ─── URL Helpers ─────────────────────────────────────────────────────────────

def normalize_url(url: str) -> str:
    """
    Normalize a user-supplied URL: add https:// if missing, strip trailing slash.
    """
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    # Remove trailing slash for consistency
    return url.rstrip("/")


def build_url(base: str, path: str) -> str:
    """Join a base URL and path, ensuring no double-slashes."""
    return urljoin(base.rstrip("/") + "/", path.lstrip("/"))


def get_domain(url: str) -> str:
    """Extract the domain (netloc) from a URL."""
    return urlparse(url).netloc


# ─── Rate Limiting ────────────────────────────────────────────────────────────

class RateLimiter:
    """
    Simple token-bucket style rate limiter to avoid hammering targets.
    Default: 1 request per 0.5 seconds (2 req/s).
    """

    def __init__(self, delay: float = 0.5):
        self.delay = delay
        self._last = 0.0

    def wait(self):
        """Block until the next request is allowed."""
        elapsed = time.time() - self._last
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)
        self._last = time.time()


# ─── Version Comparison ───────────────────────────────────────────────────────

def version_lt(v1: str, v2: str) -> bool:
    """
    Return True if version string v1 is less than v2.
    Supports standard dotted-integer format (e.g. '5.9.3' < '6.0.0').
    """
    def parse(v: str):
        try:
            return tuple(int(x) for x in v.strip().split("."))
        except ValueError:
            return (0,)

    return parse(v1) < parse(v2)


def version_lte(v1: str, v2: str) -> bool:
    """Return True if v1 <= v2."""
    return v1 == v2 or version_lt(v1, v2)


# ─── Finding Builder ─────────────────────────────────────────────────────────

RISK_ORDER = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Info": 0}


def make_finding(title: str, risk: str, description: str,
                 remediation: str, details: Optional[Dict[str, Any]] = None,
                 cve: Optional[str] = None) -> Dict[str, Any]:
    """
    Standardise a single security finding dict.

    Args:
        title:        Short name of the finding.
        risk:         One of Critical / High / Medium / Low / Info.
        description:  What was found and why it matters.
        remediation:  Actionable fix guidance.
        details:      Optional extra key-value pairs (URL, version, etc.).
        cve:          Optional CVE identifier.

    Returns:
        Dict ready to be appended to findings list.
    """
    finding = {
        "title": title,
        "risk": risk,
        "description": description,
        "remediation": remediation,
    }
    if cve:
        finding["cve"] = cve
    if details:
        finding["details"] = details
    return finding
