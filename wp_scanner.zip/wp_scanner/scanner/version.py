"""
version.py — Extract and assess the WordPress version from multiple sources.

Sources checked (in order of reliability):
  1. <meta name="generator"> tag in homepage HTML
  2. /feed/ (RSS) generator element
  3. /readme.html static file
  4. /wp-includes/css/dashicons.min.css?ver=X.X
  5. /wp-includes/js/wp-embed.min.js?ver=X.X
"""

import re
import logging
from typing import Optional, Dict, Any, List

import requests
from bs4 import BeautifulSoup

from .utils import safe_get, build_url, version_lt, make_finding

logger = logging.getLogger("wp_scanner.version")

# Regex patterns for version extraction
_VER_RE = re.compile(r'(?:WordPress\s+)?(\d+\.\d+(?:\.\d+)?)', re.I)
_VER_QS  = re.compile(r'\?ver=(\d+\.\d+(?:\.\d+)?)')   # query-string ?ver=

# Minimum safe WP version (update periodically)
SAFE_VERSION = "6.7.0"
LATEST_VERSION = "6.7.2"


def _extract_version(text: str) -> Optional[str]:
    """Find the first X.Y or X.Y.Z version string in arbitrary text."""
    m = _VER_RE.search(text)
    return m.group(1) if m else None


def enumerate_version(session: requests.Session, base_url: str,
                      cve_data: Dict, rate_limiter=None) -> Dict[str, Any]:
    """
    Attempt to discover the installed WordPress version via multiple passive
    sources and cross-reference it against known CVEs.

    Returns:
        {
            "version": str | None,
            "source": str | None,
            "is_outdated": bool,
            "findings": [...]
        }
    """
    findings: List[Dict] = []
    version:  Optional[str] = None
    source:   Optional[str] = None

    def _try(url: str, extractor) -> Optional[str]:
        if rate_limiter:
            rate_limiter.wait()
        resp = safe_get(session, url)
        if resp and resp.status_code == 200:
            return extractor(resp)
        return None

    # ── 1. Meta generator ────────────────────────────────────────────────────
    def _from_meta(resp: requests.Response) -> Optional[str]:
        soup = BeautifulSoup(resp.text, "html.parser")
        meta = soup.find("meta", attrs={"name": "generator"})
        if meta:
            return _extract_version(meta.get("content", ""))
        return None

    v = _try(base_url, _from_meta)
    if v:
        version, source = v, "HTML meta generator tag"
        logger.info("Version %s found via %s", version, source)

    # ── 2. RSS feed ──────────────────────────────────────────────────────────
    if not version:
        def _from_rss(resp: requests.Response) -> Optional[str]:
            # <generator>https://wordpress.org/?v=6.4.3</generator>
            m = re.search(r'wordpress\.org/\?v=(\d+\.\d+(?:\.\d+)?)',
                          resp.text, re.I)
            if m:
                return m.group(1)
            return _extract_version(resp.text)

        v = _try(build_url(base_url, "/feed/"), _from_rss)
        if v:
            version, source = v, "RSS feed /feed/"

    # ── 3. readme.html ───────────────────────────────────────────────────────
    if not version:
        def _from_readme(resp: requests.Response) -> Optional[str]:
            # Typical content: "Version 6.4.3"
            return _extract_version(resp.text)

        v = _try(build_url(base_url, "/readme.html"), _from_readme)
        if v:
            version, source = v, "/readme.html"
            # readme.html being publicly accessible is itself a finding
            findings.append(make_finding(
                title="readme.html publicly accessible",
                risk="Low",
                description=(
                    "/readme.html is publicly accessible and discloses the "
                    f"WordPress version ({version}). Attackers can use this "
                    "to target known vulnerabilities for that version."
                ),
                remediation=(
                    "Delete or restrict access to readme.html via .htaccess "
                    "or Nginx location block. Most managed hosts do this automatically."
                ),
                details={"url": build_url(base_url, "/readme.html")},
            ))

    # ── 4. Asset query-string fingerprinting ─────────────────────────────────
    if not version:
        def _from_assets(resp: requests.Response) -> Optional[str]:
            m = _VER_QS.search(resp.text)
            return m.group(1) if m else None

        for asset_path in [
            "/wp-includes/css/dashicons.min.css",
            "/wp-includes/js/wp-embed.min.js",
        ]:
            # We probe the homepage source for asset references
            break   # these are found passively in homepage HTML, not direct fetch

        # Passive: scan homepage HTML for ?ver= attached to wp- assets
        if rate_limiter:
            rate_limiter.wait()
        hp = safe_get(session, base_url)
        if hp:
            matches = _VER_QS.findall(hp.text)
            # Filter out plugin/theme versions (short numbers) and pick majority
            from collections import Counter
            counts = Counter(m for m in matches if re.match(r'\d+\.\d+', m))
            if counts:
                v = counts.most_common(1)[0][0]
                if re.match(r'^\d+\.\d+', v):
                    version, source = v, "Asset ?ver= query parameter in HTML"

    # ── Evaluate the discovered version ──────────────────────────────────────
    is_outdated = False
    if version:
        # Normalise: "6.4" → "6.4.0" for comparison
        ver_full = version if version.count(".") >= 2 else version + ".0"
        is_outdated = version_lt(ver_full, SAFE_VERSION)

        if is_outdated:
            # Look up CVEs for this version
            core_cves = _find_core_cves(version, cve_data)
            cve_list  = ", ".join(c["cve"] for c in core_cves) if core_cves else "multiple known CVEs"

            findings.append(make_finding(
                title=f"Outdated WordPress version: {version}",
                risk="High",
                description=(
                    f"The target is running WordPress {version} (latest: "
                    f"{LATEST_VERSION}). Outdated WordPress installations are "
                    f"frequently targeted by automated exploit kits. "
                    f"Known issues include: {cve_list}."
                ),
                remediation=(
                    f"Update to WordPress {LATEST_VERSION} immediately via "
                    "Dashboard → Updates, or use WP-CLI: `wp core update`."
                ),
                details={
                    "detected_version": version,
                    "latest_version": LATEST_VERSION,
                    "source": source,
                    "cves": core_cves,
                },
                cve=core_cves[0]["cve"] if core_cves else None,
            ))
        else:
            logger.info("WordPress %s is current (≥ %s)", version, SAFE_VERSION)
    else:
        logger.info("Could not determine WordPress version for %s", base_url)

    return {
        "version": version,
        "source": source,
        "is_outdated": is_outdated,
        "findings": findings,
    }


def _find_core_cves(version: str, cve_data: Dict) -> List[Dict]:
    """
    Return a list of CVE dicts from cve_data that affect `version` or older.
    The cve_data key is the *last vulnerable* version (patch boundary).
    """
    affected = []
    core_map = cve_data.get("wordpress_core", {})
    for boundary_ver, cves in core_map.items():
        # If installed version ≤ boundary, the CVE applies
        if version_lt(version, boundary_ver) or version == boundary_ver:
            affected.extend(cves)
    return affected
