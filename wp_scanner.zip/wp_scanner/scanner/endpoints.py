"""
endpoints.py — Check WordPress-specific endpoints and files for common
vulnerabilities and misconfigurations.

Checks performed:
  - Sensitive file exposure (wp-config.php backups, .env, .git, debug.log)
  - Directory listing enabled
  - XML-RPC enabled
  - REST API user enumeration
  - wp-login.php / wp-admin exposure
  - Author enumeration via /?author=N
  - Login brute-force protection indicators
  - WAF / CDN detection
"""

import re
import logging
from typing import Dict, Any, List

import requests

from .utils import safe_get, safe_head, build_url, make_finding

logger = logging.getLogger("wp_scanner.endpoints")


# ── Sensitive file paths to probe ─────────────────────────────────────────────

SENSITIVE_FILES = [
    # wp-config backups
    ("/wp-config.php",            "Critical", "WordPress configuration file (DB creds, auth keys)"),
    ("/wp-config.php.bak",        "Critical", "wp-config.php backup — may expose database credentials"),
    ("/wp-config.php.old",        "Critical", "wp-config.php backup — may expose database credentials"),
    ("/wp-config.php~",           "Critical", "wp-config.php editor temp file"),
    ("/wp-config.bak",            "Critical", "WordPress config backup file"),
    ("/wp-config.txt",            "High",     "WordPress config exported as plaintext"),
    # Environment & secrets
    ("/.env",                     "Critical", ".env file — commonly contains DB, API, and SMTP credentials"),
    ("/.env.bak",                 "Critical", ".env backup file with sensitive credentials"),
    ("/.env.local",               "Critical", ".env local override with credentials"),
    # Git exposure
    ("/.git/config",              "High",     "Git config file — may expose remote URL, credentials, and history"),
    ("/.git/HEAD",                "High",     "Git HEAD file — confirms .git directory is exposed"),
    ("/.gitignore",               "Low",      ".gitignore discloses project structure and ignored paths"),
    # Debug and log files
    ("/wp-content/debug.log",     "High",     "WordPress debug log — may contain stack traces, paths, user data"),
    ("/debug.log",                "High",     "Debug log file — may expose sensitive runtime information"),
    ("/error_log",                "Medium",   "PHP error log — may expose file paths and function names"),
    # WordPress info files
    ("/license.txt",              "Low",      "license.txt confirms WordPress installation and can aid fingerprinting"),
    ("/wp-links-opml.php",        "Low",      "OPML export reveals internal link structure"),
    # Installation files that should be removed
    ("/wp-admin/install.php",     "Medium",   "WordPress installation script — should not be accessible post-install"),
    ("/wp-admin/upgrade.php",     "Medium",   "WordPress upgrade script — may disclose version info"),
    # Backup plugin artifacts
    ("/backup.sql",               "Critical", "Database SQL dump — full database exposure"),
    ("/backup.zip",               "High",     "Site backup archive — may contain source code and credentials"),
    ("/wp-content/uploads/backup.sql", "Critical", "DB backup in uploads directory"),
    # phpinfo exposure
    ("/phpinfo.php",              "High",     "phpinfo() output — exposes full server configuration"),
    ("/info.php",                 "High",     "phpinfo() output — exposes full server configuration"),
]

# Directories to check for directory listing
DIRECTORY_LISTING_PATHS = [
    "/wp-content/uploads/",
    "/wp-content/plugins/",
    "/wp-content/themes/",
    "/wp-includes/",
]

# Indicators that suggest directory listing is ON
_DIR_LISTING_MARKERS = [
    "index of",
    "parent directory",
    "<title>index of",
    "last modified</a>",
    "directory listing for",
]


def _is_dir_listing(html: str) -> bool:
    low = html.lower()
    return any(m in low for m in _DIR_LISTING_MARKERS)


def check_sensitive_files(session: requests.Session, base_url: str,
                          rate_limiter=None) -> List[Dict]:
    """Probe for sensitive/exposed files and return findings."""
    findings = []

    for path, risk, description in SENSITIVE_FILES:
        if rate_limiter:
            rate_limiter.wait()
        url  = build_url(base_url, path)
        resp = safe_get(session, url, allow_redirects=True)

        if resp is None:
            continue

        # A 200 with non-trivial body size is the indicator
        if resp.status_code == 200 and len(resp.content) > 20:
            # Extra check: make sure we're not getting a custom 404 page
            # (many WP sites return 200 for missing pages)
            is_wp_404 = any(x in resp.text.lower() for x in [
                "page not found", "404", "nothing found", "no page",
            ])
            if is_wp_404 and "wp-config" not in path:
                continue

            findings.append(make_finding(
                title=f"Sensitive file exposed: {path}",
                risk=risk,
                description=(
                    f"{description}. The file is publicly accessible at {url}."
                ),
                remediation=(
                    f"Immediately restrict access to {path}. "
                    "For Apache: add `deny from all` in .htaccess. "
                    "For Nginx: add `location ~* {path}$ {{ deny all; }}`. "
                    "Delete backup files that are no longer needed."
                ),
                details={"url": url, "status_code": resp.status_code,
                         "content_length": len(resp.content)},
            ))
            logger.warning("[%s] Sensitive file exposed: %s", risk, url)

    return findings


def check_directory_listing(session: requests.Session, base_url: str,
                             rate_limiter=None) -> List[Dict]:
    """Check whether directory listing is enabled on key WP directories."""
    findings = []
    affected_dirs = []

    for path in DIRECTORY_LISTING_PATHS:
        if rate_limiter:
            rate_limiter.wait()
        url  = build_url(base_url, path)
        resp = safe_get(session, url)

        if resp and resp.status_code == 200 and _is_dir_listing(resp.text):
            affected_dirs.append(url)
            logger.warning("Directory listing enabled: %s", url)

    if affected_dirs:
        findings.append(make_finding(
            title="Directory listing enabled",
            risk="Medium",
            description=(
                "Directory listing is enabled on the following paths: "
                + ", ".join(affected_dirs)
                + ". Attackers can enumerate installed plugins, themes, "
                "uploaded files, and directory structure."
            ),
            remediation=(
                "Disable directory listing in your web server config. "
                "For Apache: add `Options -Indexes` to .htaccess or httpd.conf. "
                "For Nginx: set `autoindex off;` in the server block. "
                "Also add an empty index.php to sensitive directories."
            ),
            details={"affected_directories": affected_dirs},
        ))

    return findings


def check_xmlrpc(session: requests.Session, base_url: str,
                 rate_limiter=None) -> List[Dict]:
    """
    Detect if XML-RPC is enabled. An enabled XML-RPC endpoint can be abused
    for credential brute-forcing (multicall) and DDoS amplification.
    """
    findings = []
    url = build_url(base_url, "/xmlrpc.php")

    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, url)

    if resp is None:
        return []

    # XML-RPC is present if we get a 200 or 405 with XML content
    xmlrpc_present = (
        resp.status_code == 200
        and ("xml-rpc" in resp.text.lower() or "xmlrpc" in resp.text.lower())
    ) or resp.status_code == 405  # Method Not Allowed → endpoint exists

    if xmlrpc_present:
        # Check if multicall is available (higher risk)
        multicall_risk = "the system.multicall method allows" in resp.text.lower() \
                         or resp.status_code == 405

        findings.append(make_finding(
            title="XML-RPC enabled",
            risk="High",
            description=(
                "/xmlrpc.php is enabled and accessible. This exposes the site to "
                "(1) credential stuffing via the system.multicall method "
                "(10,000+ passwords per request), "
                "(2) DDoS amplification attacks using XML-RPC as a reflector, and "
                "(3) pingback-based SSRF attacks."
            ),
            remediation=(
                "Disable XML-RPC unless specifically required (e.g., by Jetpack). "
                "For Apache: add to .htaccess:\n"
                "  <Files xmlrpc.php>\n    deny from all\n  </Files>\n"
                "Alternatively use the 'Disable XML-RPC' plugin, or block via WAF rule."
            ),
            details={"url": url, "status_code": resp.status_code},
        ))

    return findings


def check_rest_api(session: requests.Session, base_url: str,
                   rate_limiter=None) -> List[Dict]:
    """
    Check if the WordPress REST API exposes user information without authentication.
    /wp-json/wp/v2/users can leak usernames, display names, and gravatar URLs.
    """
    findings = []

    # ── Check /wp-json/ top level ─────────────────────────────────────────────
    if rate_limiter:
        rate_limiter.wait()
    api_url  = build_url(base_url, "/wp-json/")
    api_resp = safe_get(session, api_url)

    if api_resp and api_resp.status_code == 200:
        try:
            api_data = api_resp.json()
            api_name = api_data.get("name", "Unknown")
        except Exception:
            api_name = "Unknown"

        findings.append(make_finding(
            title="WordPress REST API exposed",
            risk="Low",
            description=(
                f"The WordPress REST API is publicly accessible at {api_url}. "
                "While not inherently dangerous, the REST API can expose site "
                "metadata, installed capabilities, and user information."
            ),
            remediation=(
                "If the REST API is not required for public consumers, restrict "
                "unauthenticated access: add "
                "`add_filter('rest_authentication_errors', function($e){return $e?:new WP_Error(...)});` "
                "to functions.php, or use a security plugin to limit REST API access."
            ),
            details={"url": api_url, "site_name": api_name},
        ))

        # ── Check /wp-json/wp/v2/users (user enumeration) ────────────────────
        if rate_limiter:
            rate_limiter.wait()
        users_url  = build_url(base_url, "/wp-json/wp/v2/users")
        users_resp = safe_get(session, users_url)

        if users_resp and users_resp.status_code == 200:
            try:
                users = users_resp.json()
                if isinstance(users, list) and len(users) > 0:
                    user_names = [u.get("name") or u.get("slug", "?")
                                  for u in users[:5]]
                    findings.append(make_finding(
                        title="User enumeration via REST API",
                        risk="Medium",
                        description=(
                            f"The REST API endpoint {users_url} returned "
                            f"{len(users)} user record(s) without authentication. "
                            f"Exposed users: {', '.join(filter(None, user_names))}. "
                            "Usernames aid targeted brute-force and phishing attacks."
                        ),
                        remediation=(
                            "Disable unauthenticated access to the users endpoint. "
                            "Add to functions.php:\n"
                            "  add_filter('rest_endpoints', function($endpoints){\n"
                            "    unset($endpoints['/wp/v2/users']);\n"
                            "    return $endpoints;\n"
                            "  });\n"
                            "Or use a plugin like Disable REST API."
                        ),
                        details={"url": users_url, "user_count": len(users),
                                 "sample_users": user_names},
                    ))
            except Exception:
                pass

    return findings


def check_user_enumeration(session: requests.Session, base_url: str,
                            rate_limiter=None) -> List[Dict]:
    """
    Check if WordPress user enumeration is possible via /?author=1 redirect.
    A 301/302 redirect to /author/<username>/ discloses the username.
    """
    findings = []
    url = build_url(base_url, "/?author=1")

    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, url, allow_redirects=True)

    if resp is None:
        return []

    final_url = resp.url
    # Username is in the URL if it redirected to /author/<slug>/
    m = re.search(r'/author/([^/]+)/', final_url)
    if m:
        username = m.group(1)
        findings.append(make_finding(
            title="Username enumeration via author pages",
            risk="Medium",
            description=(
                f"Requesting /?author=1 redirected to {final_url}, "
                f"revealing the username '{username}'. "
                "Attackers can enumerate all users by iterating the author ID "
                "parameter, then use discovered usernames in brute-force attacks."
            ),
            remediation=(
                "Redirect /?author=[0-9]+ requests to the homepage using .htaccess:\n"
                "  RewriteCond %{QUERY_STRING} ^author=\\d\n"
                "  RewriteRule ^ /? [L,R=301]\n"
                "Or use a security plugin such as Wordfence to block author enumeration."
            ),
            details={"redirect_url": final_url, "discovered_username": username},
        ))

    return findings


def check_login_exposure(session: requests.Session, base_url: str,
                         rate_limiter=None) -> List[Dict]:
    """
    Check login/admin page exposure and assess brute-force protection.
    """
    findings = []

    login_url = build_url(base_url, "/wp-login.php")
    admin_url = build_url(base_url, "/wp-admin/")

    if rate_limiter:
        rate_limiter.wait()
    login_resp = safe_get(session, login_url)

    login_exposed = (
        login_resp
        and login_resp.status_code == 200
        and "user_login" in login_resp.text  # login form present
    )

    if login_exposed:
        html_lower = login_resp.text.lower()

        # Check for brute-force protection indicators
        protection_indicators = {
            "CAPTCHA": any(x in html_lower for x in [
                "captcha", "recaptcha", "hcaptcha", "cf-turnstile"
            ]),
            "Login limiter": any(x in html_lower for x in [
                "login attempts", "locked out", "too many", "limit"
            ]),
            "2FA": any(x in html_lower for x in [
                "two-factor", "2fa", "otp", "authenticator"
            ]),
        }

        protection_present = any(protection_indicators.values())
        active_protections = [k for k, v in protection_indicators.items() if v]

        if not protection_present:
            findings.append(make_finding(
                title="Login page exposed without brute-force protection",
                risk="High",
                description=(
                    f"/wp-login.php is publicly accessible at {login_url} "
                    "with no detectable brute-force protection (no CAPTCHA, "
                    "login limiter, or 2FA). This leaves the login form open "
                    "to automated credential stuffing and password spray attacks."
                ),
                remediation=(
                    "Implement at minimum two of: (1) login rate-limiting plugin "
                    "(Limit Login Attempts Reloaded), (2) CAPTCHA on login form, "
                    "(3) Two-Factor Authentication, (4) restrict /wp-login.php access "
                    "by IP via .htaccess if admin IPs are static, (5) change login URL "
                    "using WPS Hide Login plugin."
                ),
                details={"url": login_url, "protection_indicators": protection_indicators},
            ))
        else:
            findings.append(make_finding(
                title="Login page exposed (brute-force protection detected)",
                risk="Low",
                description=(
                    f"/wp-login.php is publicly accessible. "
                    f"Protection detected: {', '.join(active_protections)}. "
                    "Verify that protection is working correctly."
                ),
                remediation=(
                    "Consider additionally restricting /wp-login.php by IP if admin "
                    "IPs are known and static."
                ),
                details={"url": login_url, "protections": active_protections},
            ))

    return findings


def detect_waf(session: requests.Session, base_url: str,
               rate_limiter=None) -> Dict[str, Any]:
    """
    Attempt to detect WAF or CDN presence via response headers.
    Returns {"waf_detected": bool, "waf_name": str | None}.
    """
    waf_headers = {
        "CF-RAY":              "Cloudflare",
        "CF-Cache-Status":     "Cloudflare",
        "X-Sucuri-ID":         "Sucuri",
        "X-Sucuri-Cache":      "Sucuri",
        "X-Cdn":               "Generic CDN",
        "X-Cache":             "Caching layer / CDN",
        "X-Varnish":           "Varnish Cache",
        "X-Akamai-Transformed":"Akamai",
        "X-CDN":               "CDN",
        "Server":              None,   # check value separately
        "X-Powered-By-Plesk":  "Plesk",
        "x-wpe-request-id":    "WP Engine",
        "x-kinsta-cache":      "Kinsta",
        "x-cache-hits":        "CDN Cache",
    }

    server_waf_values = {
        "cloudflare": "Cloudflare",
        "sucuri":     "Sucuri",
        "shield":     "Shield Security",
    }

    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, base_url)
    if not resp:
        return {"waf_detected": False, "waf_name": None}

    detected_name = None
    headers_lower = {k.lower(): v.lower() for k, v in resp.headers.items()}

    for header, waf_name in waf_headers.items():
        if header.lower() in headers_lower:
            if waf_name:
                detected_name = waf_name
                break
            else:
                # Check Server: header value
                server_val = headers_lower.get("server", "")
                for key, name in server_waf_values.items():
                    if key in server_val:
                        detected_name = name
                        break

    return {
        "waf_detected": detected_name is not None,
        "waf_name": detected_name,
    }


def run_all_endpoint_checks(session: requests.Session, base_url: str,
                             rate_limiter=None) -> Dict[str, Any]:
    """
    Run all endpoint checks and aggregate results.

    Returns:
        {
            "findings":     [...],
            "waf_info":     {...},
            "login_url":    str,
        }
    """
    all_findings: List[Dict] = []

    logger.info("Checking sensitive files…")
    all_findings.extend(check_sensitive_files(session, base_url, rate_limiter))

    logger.info("Checking directory listing…")
    all_findings.extend(check_directory_listing(session, base_url, rate_limiter))

    logger.info("Checking XML-RPC…")
    all_findings.extend(check_xmlrpc(session, base_url, rate_limiter))

    logger.info("Checking REST API…")
    all_findings.extend(check_rest_api(session, base_url, rate_limiter))

    logger.info("Checking user enumeration via author pages…")
    all_findings.extend(check_user_enumeration(session, base_url, rate_limiter))

    logger.info("Checking login page exposure…")
    all_findings.extend(check_login_exposure(session, base_url, rate_limiter))

    logger.info("Detecting WAF / CDN…")
    waf_info = detect_waf(session, base_url, rate_limiter)

    if not waf_info["waf_detected"]:
        all_findings.append(make_finding(
            title="No WAF / CDN detected",
            risk="Info",
            description=(
                "No Web Application Firewall or CDN was detected in front of "
                "the target. WAFs provide an important layer of defence against "
                "common web attacks (SQLi, XSS, brute force)."
            ),
            remediation=(
                "Consider placing the site behind a WAF/CDN such as Cloudflare "
                "(free tier available), Sucuri, or a server-level WAF like ModSecurity."
            ),
        ))

    return {
        "findings": all_findings,
        "waf_info": waf_info,
        "login_url": build_url(base_url, "/wp-login.php"),
    }
