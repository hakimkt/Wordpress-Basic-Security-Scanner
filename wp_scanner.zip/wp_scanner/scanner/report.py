"""
report.py — Aggregate all scan results and produce structured JSON and
human-readable terminal reports with colour-coded risk levels.
"""

import json
import datetime
import logging
from typing import Dict, Any, List, Optional

from .utils import RISK_ORDER

logger = logging.getLogger("wp_scanner.report")

# ANSI colour codes for terminal output
_COLOURS = {
    "Critical": "\033[91m",   # Bright Red
    "High":     "\033[31m",   # Red
    "Medium":   "\033[93m",   # Yellow
    "Low":      "\033[94m",   # Blue
    "Info":     "\033[96m",   # Cyan
    "RESET":    "\033[0m",
    "BOLD":     "\033[1m",
    "GREEN":    "\033[92m",
    "DIM":      "\033[2m",
}

RISK_ICONS = {
    "Critical": "🔴",
    "High":     "🟠",
    "Medium":   "🟡",
    "Low":      "🔵",
    "Info":     "⚪",
}


def build_report(
    target_url: str,
    scan_start: datetime.datetime,
    scan_end: datetime.datetime,
    wp_detected: bool,
    wp_confidence: int,
    wp_signals: List[str],
    wp_version: Optional[str],
    wp_version_source: Optional[str],
    wp_outdated: bool,
    plugins: List[Dict],
    theme: Optional[Dict],
    waf_info: Dict,
    all_findings: List[Dict],
) -> Dict[str, Any]:
    """
    Assemble the final scan report dictionary.

    This is the canonical data structure — both JSON output and the terminal
    report are derived from it.
    """
    duration = (scan_end - scan_start).total_seconds()

    # Deduplicate findings by title (some checks may overlap)
    seen_titles = set()
    unique_findings = []
    for f in all_findings:
        if f["title"] not in seen_titles:
            seen_titles.add(f["title"])
            unique_findings.append(f)

    # Sort findings by risk (Critical first)
    unique_findings.sort(
        key=lambda f: RISK_ORDER.get(f.get("risk", "Info"), 0),
        reverse=True,
    )

    # Risk summary counts
    risk_summary = {r: 0 for r in ["Critical", "High", "Medium", "Low", "Info"]}
    for f in unique_findings:
        risk_summary[f.get("risk", "Info")] = \
            risk_summary.get(f.get("risk", "Info"), 0) + 1

    # Risk score (rough composite)
    risk_weights = {"Critical": 40, "High": 20, "Medium": 8, "Low": 2, "Info": 0}
    risk_score = min(100, sum(
        risk_weights.get(r, 0) * count
        for r, count in risk_summary.items()
    ))

    return {
        "meta": {
            "scanner":     "WP Security Scanner v1.0",
            "target":      target_url,
            "scan_start":  scan_start.isoformat(),
            "scan_end":    scan_end.isoformat(),
            "duration_s":  round(duration, 2),
            "generated":   datetime.datetime.utcnow().isoformat() + "Z",
        },
        "wordpress": {
            "detected":       wp_detected,
            "confidence_pct": wp_confidence,
            "detection_signals": wp_signals,
            "version":        wp_version,
            "version_source": wp_version_source,
            "is_outdated":    wp_outdated,
        },
        "environment": {
            "waf_detected": waf_info.get("waf_detected", False),
            "waf_name":     waf_info.get("waf_name"),
            "plugins_detected": plugins,
            "theme_detected":   theme,
        },
        "risk_summary": risk_summary,
        "risk_score":   risk_score,
        "findings":     unique_findings,
    }


def print_terminal_report(report: Dict[str, Any], use_color: bool = True) -> str:
    """
    Render a rich terminal-formatted report from the report dict.
    Returns the rendered string (also prints it).
    """
    c = _COLOURS if use_color else {k: "" for k in _COLOURS}
    lines = []

    def ln(s=""):
        lines.append(s)

    hr_thick = "═" * 70
    hr_thin  = "─" * 70

    # ── Header ────────────────────────────────────────────────────────────────
    ln(f"{c['BOLD']}{hr_thick}")
    ln(f"  WP SECURITY SCANNER — REPORT")
    ln(f"{hr_thick}{c['RESET']}")

    meta = report["meta"]
    wp   = report["wordpress"]
    env  = report["environment"]

    ln(f"  {c['DIM']}Target   :{c['RESET']} {meta['target']}")
    ln(f"  {c['DIM']}Scanned  :{c['RESET']} {meta['scan_start'][:19].replace('T',' ')}")
    ln(f"  {c['DIM']}Duration :{c['RESET']} {meta['duration_s']}s")
    ln()

    # ── WordPress Detection ───────────────────────────────────────────────────
    ln(f"{c['BOLD']}  WORDPRESS DETECTION{c['RESET']}")
    ln(f"  {hr_thin}")
    detected_str = (
        f"{c['GREEN']}✔ DETECTED{c['RESET']}" if wp["detected"]
        else f"{c['Critical']}\033[91m✘ NOT DETECTED{c['RESET']}"
    )
    ln(f"  Status        : {detected_str}  (confidence: {wp['confidence_pct']}%)")

    if wp["version"]:
        outdated_flag = (
            f" {c['High']}← OUTDATED{c['RESET']}" if wp["is_outdated"] else
            f" {c['GREEN']}← Current{c['RESET']}"
        )
        ln(f"  Version       : {wp['version']}{outdated_flag}")
        ln(f"  Version source: {wp['version_source']}")
    else:
        ln(f"  Version       : {c['DIM']}Could not determine{c['RESET']}")

    # WAF
    waf_str = (
        f"{c['GREEN']}✔ {env['waf_name']}{c['RESET']}" if env["waf_detected"]
        else f"{c['DIM']}Not detected{c['RESET']}"
    )
    ln(f"  WAF / CDN     : {waf_str}")
    ln()

    # ── Plugins & Themes ──────────────────────────────────────────────────────
    plugins = env["plugins_detected"]
    theme   = env["theme_detected"]

    ln(f"{c['BOLD']}  PLUGINS & THEMES{c['RESET']}")
    ln(f"  {hr_thin}")
    if plugins:
        ln(f"  Plugins detected ({len(plugins)}):")
        for p in plugins[:15]:   # cap display at 15
            ver = p.get("version", "unknown")
            ln(f"    • {p['slug']} — v{ver}")
        if len(plugins) > 15:
            ln(f"    … and {len(plugins) - 15} more")
    else:
        ln(f"  {c['DIM']}No plugins detected{c['RESET']}")

    if theme:
        ln(f"  Active theme  : {theme['slug']} (v{theme.get('version','unknown')})")
    ln()

    # ── Risk Summary ─────────────────────────────────────────────────────────
    risk_summary = report["risk_summary"]
    risk_score   = report["risk_score"]

    ln(f"{c['BOLD']}  RISK SUMMARY{c['RESET']}")
    ln(f"  {hr_thin}")
    for level in ["Critical", "High", "Medium", "Low", "Info"]:
        count = risk_summary.get(level, 0)
        col   = c.get(level, "")
        icon  = RISK_ICONS.get(level, "•")
        bar   = "█" * min(count, 30)
        ln(f"  {icon} {col}{level:<10}{c['RESET']}  {count:>3}  {col}{bar}{c['RESET']}")
    ln()
    # Risk score meter
    score_col = (
        c["Critical"] if risk_score >= 60 else
        c["High"]     if risk_score >= 40 else
        c["Medium"]   if risk_score >= 20 else
        c["GREEN"]
    )
    filled = int(risk_score / 100 * 40)
    bar = "█" * filled + "░" * (40 - filled)
    ln(f"  Risk Score: {score_col}{risk_score}/100{c['RESET']}")
    ln(f"  [{score_col}{bar}{c['RESET']}]")
    ln()

    # ── Findings ─────────────────────────────────────────────────────────────
    findings = report["findings"]
    ln(f"{c['BOLD']}  FINDINGS ({len(findings)} total){c['RESET']}")
    ln(f"  {hr_thick}")

    if not findings:
        ln(f"  {c['GREEN']}No findings — target appears well-configured.{c['RESET']}")
    else:
        for i, f in enumerate(findings, 1):
            risk   = f.get("risk", "Info")
            col    = c.get(risk, "")
            icon   = RISK_ICONS.get(risk, "•")
            cve_str = f"  CVE: {f['cve']}" if f.get("cve") else ""

            ln()
            ln(f"  {i:>2}. {icon} {c['BOLD']}{col}[{risk}]{c['RESET']}"
               f" {c['BOLD']}{f['title']}{c['RESET']}{cve_str}")
            ln(f"  {hr_thin}")
            # Word-wrap description at 68 chars
            desc_lines = _wrap(f.get("description", ""), 66)
            for dl in desc_lines:
                ln(f"      {dl}")
            ln()
            rem_lines = _wrap(f"✔ FIX: {f.get('remediation', '')}", 66)
            for rl in rem_lines:
                ln(f"      {c['GREEN']}{rl}{c['RESET']}")

            # Optional details
            details = f.get("details", {})
            if details:
                url = details.get("url") or details.get("redirect_url")
                if url:
                    ln(f"      {c['DIM']}URL: {url}{c['RESET']}")
                cve_list = details.get("cves", [])
                if cve_list:
                    cves_str = ", ".join(c_["cve"] for c_ in cve_list[:3])
                    ln(f"      {c['DIM']}CVEs: {cves_str}{c['RESET']}")

    ln()
    ln(f"{c['BOLD']}{hr_thick}{c['RESET']}")
    ln(f"  {c['DIM']}Scan complete. This report is for authorised use only.{c['RESET']}")
    ln(f"{c['BOLD']}{hr_thick}{c['RESET']}")

    output = "\n".join(lines)
    print(output)
    return output


def save_json_report(report: Dict[str, Any], filepath: str) -> None:
    """Serialise the report dict to a JSON file."""
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, default=str)
    logger.info("JSON report saved to: %s", filepath)


def save_text_report(text: str, filepath: str) -> None:
    """Save the text report (ANSI stripped) to a file."""
    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    clean_text = ansi_escape.sub("", text)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(clean_text)
    logger.info("Text report saved to: %s", filepath)


def _wrap(text: str, width: int) -> List[str]:
    """Simple word-wrap that preserves newlines."""
    import textwrap
    lines = []
    for paragraph in text.split("\n"):
        wrapped = textwrap.wrap(paragraph, width=width) or [""]
        lines.extend(wrapped)
    return lines
