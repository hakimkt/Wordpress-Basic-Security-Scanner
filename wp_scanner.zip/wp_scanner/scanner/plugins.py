"""
plugins.py — Enumerate installed WordPress plugins and themes via passive and
semi-passive techniques, then cross-reference with known CVE data.

Techniques used:
  1. Passive scraping of homepage/sitemap HTML for /wp-content/plugins/<slug>/
  2. Active probing of common plugin slugs (HEAD requests only)
  3. Theme detection from /wp-content/themes/<slug>/
  4. Version extraction from plugin/theme asset filenames and readme.txt
"""

import re
import logging
import json
from typing import Dict, Any, List, Optional, Set

import requests
from bs4 import BeautifulSoup

from .utils import safe_get, safe_head, build_url, make_finding, version_lte

logger = logging.getLogger("wp_scanner.plugins")

# Regex to extract plugin/theme slugs from page source
_PLUGIN_RE = re.compile(r'/wp-content/plugins/([a-z0-9\-_]+)/', re.I)
_THEME_RE  = re.compile(r'/wp-content/themes/([a-z0-9\-_]+)/',  re.I)
_VER_RE    = re.compile(r'(?:Stable tag|Version)\s*:\s*(\d+\.\d+(?:\.\d+)?)', re.I)
_VER_QS    = re.compile(r'\?ver=(\d+\.\d+(?:\.\d+)?)')


def _extract_plugin_version(text: str) -> Optional[str]:
    m = _VER_RE.search(text)
    return m.group(1) if m else None


def _scrape_slugs(html: str) -> tuple[Set[str], Set[str]]:
    """Extract plugin and theme slugs from raw HTML."""
    plugins = set(_PLUGIN_RE.findall(html))
    themes  = set(_THEME_RE.findall(html))
    return plugins, themes


def _check_plugin_exists(session: requests.Session, base_url: str,
                         slug: str, rate_limiter=None) -> bool:
    """
    Probe /wp-content/plugins/<slug>/ via HEAD.
    Returns True if the server responds with anything except 404.
    """
    url = build_url(base_url, f"/wp-content/plugins/{slug}/")
    if rate_limiter:
        rate_limiter.wait()
    resp = safe_head(session, url)
    if resp is None:
        return False
    # 200 = directory listing, 403 = exists but forbidden, 301/302 = redirect
    return resp.status_code in (200, 403, 301, 302)


def _fetch_plugin_version(session: requests.Session, base_url: str,
                          slug: str, rate_limiter=None) -> Optional[str]:
    """
    Try to read the plugin's readme.txt to extract its version.
    Falls back to stylesheet.css for themes.
    """
    readme_url = build_url(base_url, f"/wp-content/plugins/{slug}/readme.txt")
    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, readme_url)
    if resp and resp.status_code == 200:
        return _extract_plugin_version(resp.text)
    return None


def _check_theme_version(session: requests.Session, base_url: str,
                         slug: str, rate_limiter=None) -> Optional[str]:
    """Read theme's style.css for version info."""
    css_url = build_url(base_url, f"/wp-content/themes/{slug}/style.css")
    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, css_url)
    if resp and resp.status_code == 200:
        return _extract_plugin_version(resp.text)
    return None


def _evaluate_plugin(slug: str, version: Optional[str],
                     cve_data: Dict) -> List[Dict]:
    """
    Compare a discovered plugin slug+version against the CVE database.
    Returns a list of finding dicts (one per relevant vulnerability).
    """
    findings = []
    plugin_db = cve_data.get("plugins", {})
    if slug not in plugin_db:
        return []

    plugin_info = plugin_db[slug]
    plugin_name = plugin_info.get("name", slug)

    for vuln in plugin_info.get("vulnerabilities", []):
        # Parse "affected_versions" field like "<= 5.3.1"
        affected_str = vuln.get("affected_versions", "")
        is_affected = _is_version_affected(version, affected_str)

        if is_affected or version is None:
            cve_id   = vuln.get("cve", "Unknown")
            cvss     = vuln.get("cvss", 0)
            desc     = vuln.get("description", "No description")
            severity = vuln.get("severity", "Medium")

            version_note = f" (installed: {version})" if version else \
                           " (version unknown — assume affected)"

            findings.append(make_finding(
                title=f"Vulnerable plugin: {plugin_name}{version_note}",
                risk=severity,
                description=(
                    f"Plugin '{plugin_name}' ({slug}){version_note} is "
                    f"affected by {cve_id} — {desc}. "
                    f"CVSS Score: {cvss}."
                ),
                remediation=(
                    f"Update '{plugin_name}' to the latest version immediately "
                    "via Dashboard → Plugins → Update, or deactivate/remove "
                    "the plugin if it is not required."
                ),
                details={
                    "plugin": slug,
                    "installed_version": version,
                    "affected_versions": affected_str,
                    "cvss": cvss,
                },
                cve=cve_id,
            ))

    return findings


def _evaluate_theme(slug: str, version: Optional[str], cve_data: Dict) -> List[Dict]:
    """Compare a discovered theme against the CVE database."""
    findings = []
    theme_db = cve_data.get("themes", {})
    if slug not in theme_db:
        return []

    theme_info = theme_db[slug]
    theme_name = theme_info.get("name", slug)

    for vuln in theme_info.get("vulnerabilities", []):
        affected_str = vuln.get("affected_versions", "")
        if _is_version_affected(version, affected_str) or version is None:
            cve_id   = vuln.get("cve", "Unknown")
            severity = vuln.get("severity", "Medium")
            desc     = vuln.get("description", "")

            findings.append(make_finding(
                title=f"Vulnerable theme: {theme_name}",
                risk=severity,
                description=(
                    f"Theme '{theme_name}' ({slug}) is affected by {cve_id}: {desc}."
                ),
                remediation=(
                    f"Update theme '{theme_name}' to the latest version via "
                    "Dashboard → Appearance → Themes."
                ),
                details={"theme": slug, "installed_version": version},
                cve=cve_id,
            ))

    return findings


def _is_version_affected(installed: Optional[str], constraint: str) -> bool:
    """
    Evaluate a version constraint string like '<= 5.3.1'.
    Supported operators: <=, <, >=, >
    Returns True if installed version satisfies the constraint (i.e., is affected).
    """
    if not installed or not constraint:
        return True   # If version unknown, assume affected (conservative)

    m = re.match(r'([<>]=?)\s*(\d+\.\d+(?:\.\d+)?)', constraint.strip())
    if not m:
        return False

    op, boundary = m.group(1), m.group(2)

    # Normalise both to X.Y.Z
    def norm(v):
        parts = v.split(".")
        while len(parts) < 3:
            parts.append("0")
        return tuple(int(x) for x in parts)

    iv = norm(installed)
    bv = norm(boundary)

    return {
        "<=": iv <= bv,
        "<":  iv <  bv,
        ">=": iv >= bv,
        ">":  iv >  bv,
    }.get(op, False)


def enumerate_plugins(session: requests.Session, base_url: str,
                      cve_data: Dict, rate_limiter=None,
                      active_probe: bool = True) -> Dict[str, Any]:
    """
    Main entry point for plugin & theme enumeration.

    Args:
        session:      Configured requests.Session.
        base_url:     Normalised target URL.
        cve_data:     Loaded CVE JSON data.
        rate_limiter: Optional RateLimiter instance.
        active_probe: If True, also actively probe common plugin slugs.

    Returns:
        {
            "plugins_detected": [{"slug": ..., "version": ..., "source": ...}],
            "theme_detected":   {"slug": ..., "version": ...} | None,
            "findings":         [...]
        }
    """
    findings: List[Dict]  = []
    plugins_detected: List[Dict] = []
    theme_detected: Optional[Dict] = None

    # ── Step 1: Collect page sources for passive scraping ────────────────────
    pages_to_scrape = [base_url]
    # Also try common additional pages
    for extra in ["/sitemap.xml", "/feed/", "/?p=1"]:
        pages_to_scrape.append(build_url(base_url, extra))

    all_plugin_slugs: Set[str] = set()
    all_theme_slugs:  Set[str] = set()

    for page_url in pages_to_scrape:
        if rate_limiter:
            rate_limiter.wait()
        resp = safe_get(session, page_url)
        if resp and resp.status_code == 200:
            p_slugs, t_slugs = _scrape_slugs(resp.text)
            all_plugin_slugs.update(p_slugs)
            all_theme_slugs.update(t_slugs)

    logger.info("Passive scrape found plugins: %s", all_plugin_slugs)
    logger.info("Passive scrape found themes:  %s", all_theme_slugs)

    # ── Step 2: Active probing of common plugin slugs ────────────────────────
    if active_probe:
        common_slugs = cve_data.get("common_plugins", [])
        logger.info("Active probing %d common plugin slugs…", len(common_slugs))
        for slug in common_slugs:
            if slug not in all_plugin_slugs:
                if _check_plugin_exists(session, base_url, slug, rate_limiter):
                    logger.debug("Active probe confirmed: %s", slug)
                    all_plugin_slugs.add(slug)

    # ── Step 3: Fetch versions + evaluate vulnerabilities ────────────────────
    for slug in sorted(all_plugin_slugs):
        version = _fetch_plugin_version(session, base_url, slug, rate_limiter)
        source  = "passive" if slug in _scrape_slugs(
            safe_get(session, base_url).text if safe_get(session, base_url) else "")[0] \
            else "active probe"

        plugins_detected.append({
            "slug": slug,
            "version": version or "unknown",
            "source": source,
        })

        plugin_findings = _evaluate_plugin(slug, version, cve_data)
        findings.extend(plugin_findings)

    # ── Step 4: Theme detection ───────────────────────────────────────────────
    if all_theme_slugs:
        # Use the first detected theme (active theme is referenced most)
        slug = sorted(all_theme_slugs)[0]
        version = _check_theme_version(session, base_url, slug, rate_limiter)
        theme_detected = {"slug": slug, "version": version or "unknown"}
        logger.info("Active theme detected: %s (%s)", slug, version)

        theme_findings = _evaluate_theme(slug, version, cve_data)
        findings.extend(theme_findings)
    else:
        # Try to detect theme via stylesheet in homepage
        if rate_limiter:
            rate_limiter.wait()
        hp = safe_get(session, base_url)
        if hp:
            m = re.search(r'/wp-content/themes/([a-z0-9\-_]+)/style\.css', hp.text, re.I)
            if m:
                slug = m.group(1)
                version = _check_theme_version(session, base_url, slug, rate_limiter)
                theme_detected = {"slug": slug, "version": version or "unknown"}
                theme_findings = _evaluate_theme(slug, version, cve_data)
                findings.extend(theme_findings)

    # ── Step 5: Generic exposure finding if many plugins detected ────────────
    if len(plugins_detected) >= 5:
        findings.append(make_finding(
            title=f"Large plugin surface area ({len(plugins_detected)} plugins detected)",
            risk="Info",
            description=(
                f"{len(plugins_detected)} plugins were detected. Each plugin represents "
                "an additional attack surface. Unused or unmaintained plugins significantly "
                "increase the risk of compromise."
            ),
            remediation=(
                "Deactivate and delete plugins that are not actively needed. "
                "Keep all active plugins updated. Subscribe to the WP security "
                "newsletter (https://wordpress.org/news/category/security/) for alerts."
            ),
            details={"count": len(plugins_detected)},
        ))

    return {
        "plugins_detected": plugins_detected,
        "theme_detected": theme_detected,
        "findings": findings,
    }
