"""
detector.py — Determine whether a target URL is running WordPress.

Uses a confidence-scoring approach across multiple independent signals so
that a single missing indicator does not produce a false negative.
"""

import logging
import re
from typing import Dict, Any, Optional

import requests
from bs4 import BeautifulSoup

from .utils import safe_get, build_url, make_finding

logger = logging.getLogger("wp_scanner.detector")

# Confidence thresholds
CONFIDENCE_CERTAIN  = 80   # ≥ this → definitely WP
CONFIDENCE_LIKELY   = 40   # ≥ this → probably WP


def detect_wordpress(session: requests.Session, base_url: str,
                     rate_limiter=None) -> Dict[str, Any]:
    """
    Run all WordPress-detection heuristics and return a result dict.

    Returns:
        {
            "is_wordpress": bool,
            "confidence": int (0-100),
            "signals": [str, ...],   # human-readable evidence list
            "findings": [...]        # standardised finding dicts (if any)
        }
    """
    score = 0
    signals = []
    findings = []

    # ── 1. Fetch the homepage ────────────────────────────────────────────────
    if rate_limiter:
        rate_limiter.wait()
    homepage = safe_get(session, base_url)

    if homepage is None:
        logger.warning("Could not reach %s", base_url)
        return {"is_wordpress": False, "confidence": 0,
                "signals": ["Target unreachable"], "findings": []}

    html  = homepage.text
    soup  = BeautifulSoup(html, "html.parser")

    # ── 2. Meta generator tag ────────────────────────────────────────────────
    meta_gen = soup.find("meta", attrs={"name": "generator"})
    if meta_gen and "wordpress" in (meta_gen.get("content", "") or "").lower():
        score += 40
        signals.append(f"Meta generator tag: {meta_gen.get('content', '')}")

    # ── 3. wp-content in page source ────────────────────────────────────────
    if "/wp-content/" in html:
        score += 25
        signals.append("'/wp-content/' found in page source")

    # ── 4. wp-includes in page source ───────────────────────────────────────
    if "/wp-includes/" in html:
        score += 15
        signals.append("'/wp-includes/' found in page source")

    # ── 5. Link rel=https://api.w.org/ (REST API header) ────────────────────
    link_header = homepage.headers.get("Link", "")
    if "api.w.org" in link_header:
        score += 20
        signals.append("REST API link in response header (api.w.org)")

    # ── 6. X-Powered-By or X-WP header ──────────────────────────────────────
    for header_name in ("X-Powered-By", "X-WP-Nonce", "X-WP-Total"):
        if header_name in homepage.headers:
            score += 10
            signals.append(f"WordPress header detected: {header_name}")
            break

    # ── 7. /wp-login.php existence ───────────────────────────────────────────
    if rate_limiter:
        rate_limiter.wait()
    login_resp = safe_get(session, build_url(base_url, "/wp-login.php"))
    if login_resp and login_resp.status_code == 200 \
            and "wordpress" in login_resp.text.lower():
        score += 30
        signals.append("/wp-login.php accessible and contains WordPress markup")

    # ── 8. /wp-admin/ redirect ───────────────────────────────────────────────
    if rate_limiter:
        rate_limiter.wait()
    admin_resp = safe_get(session, build_url(base_url, "/wp-admin/"),
                          allow_redirects=False)
    if admin_resp and admin_resp.status_code in (301, 302):
        score += 10
        signals.append("/wp-admin/ returns redirect (typical WP behaviour)")

    # ── 9. /wp-json/ endpoint ───────────────────────────────────────────────
    if rate_limiter:
        rate_limiter.wait()
    json_resp = safe_get(session, build_url(base_url, "/wp-json/"))
    if json_resp and json_resp.status_code == 200:
        try:
            data = json_resp.json()
            if "namespace" in str(data) or "wp/v2" in str(data):
                score += 20
                signals.append("/wp-json/ returns WordPress REST API data")
        except Exception:
            pass

    # ── 10. CSS/JS with wp- prefix ──────────────────────────────────────────
    wp_asset_pattern = re.compile(r'/(wp-content|wp-includes)/[^"\']+\.(css|js)', re.I)
    if wp_asset_pattern.search(html):
        score += 10
        signals.append("WordPress asset paths (wp-content/wp-includes) in source")

    # ── Normalise to 0-100 ────────────────────────────────────────────────────
    confidence = min(score, 100)
    is_wordpress = confidence >= CONFIDENCE_LIKELY

    logger.info("WordPress detection confidence: %d%% for %s", confidence, base_url)

    return {
        "is_wordpress": is_wordpress,
        "confidence": confidence,
        "signals": signals,
        "findings": findings,
    }
