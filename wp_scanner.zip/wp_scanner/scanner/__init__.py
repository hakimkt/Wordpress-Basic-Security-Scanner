"""
WordPress Security Scanner
A modular, non-intrusive black-box security assessment tool.
"""

__version__ = "1.0.0"
__author__ = "WP Security Scanner"
