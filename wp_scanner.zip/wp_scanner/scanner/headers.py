"""
headers.py — Analyse HTTP security headers and SSL/TLS configuration.

Checks performed:
  - Content-Security-Policy (CSP)
  - Strict-Transport-Security (HSTS)
  - X-Frame-Options
  - X-Content-Type-Options
  - Referrer-Policy
  - Permissions-Policy
  - X-XSS-Protection (legacy but still informative)
  - Server / X-Powered-By information disclosure
  - HTTPS enforcement (redirect from HTTP)
  - Cookie security flags (Secure, HttpOnly, SameSite)
"""

import logging
import ssl
import socket
from typing import Dict, Any, List, Optional
from urllib.parse import urlparse

import requests

from .utils import safe_get, build_url, make_finding

logger = logging.getLogger("wp_scanner.headers")


# ─── Header definitions: (header_name, risk_if_missing, description, remediation)

SECURITY_HEADERS = [
    (
        "Content-Security-Policy",
        "Medium",
        "CSP controls which resources the browser is allowed to load, "
        "preventing XSS and data injection attacks.",
        "Add a restrictive CSP. Start with: "
        "`Content-Security-Policy: default-src 'self'; script-src 'self'; "
        "object-src 'none'; base-uri 'self';`. "
        "Use plugins like WP Content Security Policy or configure in your server."
    ),
    (
        "Strict-Transport-Security",
        "Medium",
        "HSTS forces browsers to use HTTPS, preventing SSL-stripping attacks "
        "and protocol downgrade attacks.",
        "Add `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload` "
        "to your server configuration. Ensure HTTPS is properly configured first."
    ),
    (
        "X-Frame-Options",
        "Medium",
        "X-Frame-Options prevents clickjacking by controlling whether the page "
        "can be displayed in a frame or iframe.",
        "Add `X-Frame-Options: SAMEORIGIN` or use CSP `frame-ancestors 'self'`. "
        "For WordPress: add to .htaccess or configure via security plugin."
    ),
    (
        "X-Content-Type-Options",
        "Low",
        "Without X-Content-Type-Options: nosniff, browsers may MIME-sniff "
        "responses, potentially executing malicious content.",
        "Add `X-Content-Type-Options: nosniff` to all responses. "
        "This is a single-line server config change."
    ),
    (
        "Referrer-Policy",
        "Low",
        "Without Referrer-Policy, the browser sends the full URL in the Referer "
        "header, leaking internal URLs and session tokens to third parties.",
        "Add `Referrer-Policy: strict-origin-when-cross-origin` to limit "
        "referrer information to the origin only on cross-origin requests."
    ),
    (
        "Permissions-Policy",
        "Low",
        "Permissions-Policy (formerly Feature-Policy) controls access to "
        "browser features like camera, microphone, and geolocation.",
        "Add `Permissions-Policy: camera=(), microphone=(), geolocation=()` "
        "to restrict unused browser APIs."
    ),
]


def check_security_headers(session: requests.Session, base_url: str,
                            rate_limiter=None) -> List[Dict]:
    """
    Fetch the target homepage and analyse HTTP security headers.
    Returns a list of finding dicts for missing or weak headers.
    """
    findings = []

    if rate_limiter:
        rate_limiter.wait()
    resp = safe_get(session, base_url)

    if resp is None:
        logger.warning("Could not fetch %s for header analysis", base_url)
        return []

    present_headers = {k.lower(): v for k, v in resp.headers.items()}

    # ── 1. Required security headers ─────────────────────────────────────────
    for hdr_name, risk, description, remediation in SECURITY_HEADERS:
        if hdr_name.lower() not in present_headers:
            findings.append(make_finding(
                title=f"Missing security header: {hdr_name}",
                risk=risk,
                description=f"{hdr_name} header is absent. {description}",
                remediation=remediation,
                details={"header": hdr_name},
            ))
            logger.debug("Missing header: %s", hdr_name)
        else:
            # Validate CSP isn't trivially weak
            if hdr_name == "Content-Security-Policy":
                csp_val = present_headers[hdr_name.lower()]
                _findings = _validate_csp(csp_val, base_url)
                findings.extend(_findings)

            # Validate HSTS max-age is reasonable
            elif hdr_name == "Strict-Transport-Security":
                hsts_val = present_headers[hdr_name.lower()]
                _findings = _validate_hsts(hsts_val)
                findings.extend(_findings)

    # ── 2. Server information disclosure ─────────────────────────────────────
    server_header = present_headers.get("server", "")
    x_powered_by  = present_headers.get("x-powered-by", "")

    if server_header and _is_verbose_server_header(server_header):
        findings.append(make_finding(
            title="Server version disclosed in response header",
            risk="Low",
            description=(
                f"The Server header reveals detailed version information: "
                f"'{server_header}'. This aids fingerprinting and targeted attacks."
            ),
            remediation=(
                "Configure your web server to suppress version information. "
                "Apache: `ServerTokens Prod` and `ServerSignature Off`. "
                "Nginx: `server_tokens off;`."
            ),
            details={"server_header": server_header},
        ))

    if x_powered_by:
        findings.append(make_finding(
            title="X-Powered-By header discloses technology stack",
            risk="Low",
            description=(
                f"The X-Powered-By header reveals: '{x_powered_by}'. "
                "This discloses the underlying technology to attackers."
            ),
            remediation=(
                "Remove the X-Powered-By header. "
                "PHP: set `expose_php = Off` in php.ini. "
                "Apache: use `Header unset X-Powered-By`. "
                "Nginx: it is not sent by default."
            ),
            details={"x_powered_by": x_powered_by},
        ))

    # ── 3. Cookie security ────────────────────────────────────────────────────
    cookie_findings = _check_cookie_security(resp)
    findings.extend(cookie_findings)

    # ── 4. X-XSS-Protection (legacy header) ─────────────────────────────────
    xxp = present_headers.get("x-xss-protection", "")
    if xxp and xxp.strip() == "0":
        findings.append(make_finding(
            title="X-XSS-Protection is disabled",
            risk="Low",
            description=(
                "The X-XSS-Protection: 0 header explicitly disables the browser's "
                "built-in XSS filter (IE/Chrome legacy). Although modern browsers "
                "rely on CSP instead, explicitly disabling this is unusual."
            ),
            remediation=(
                "Set `X-XSS-Protection: 1; mode=block` or remove the header "
                "entirely and rely on a strong Content-Security-Policy."
            ),
        ))

    return findings


def check_https(session: requests.Session, base_url: str,
                rate_limiter=None) -> List[Dict]:
    """
    Check whether the site enforces HTTPS and test SSL/TLS configuration.
    """
    findings = []
    parsed   = urlparse(base_url)

    # ── 1. HTTP → HTTPS redirect ───────────────────────────────────────────
    if parsed.scheme == "https":
        http_url = base_url.replace("https://", "http://", 1)
        if rate_limiter:
            rate_limiter.wait()
        http_resp = safe_get(session, http_url, allow_redirects=False)

        if http_resp:
            if http_resp.status_code in (301, 302, 307, 308):
                location = http_resp.headers.get("location", "")
                if "https" in location.lower():
                    logger.info("HTTP → HTTPS redirect confirmed")
                else:
                    findings.append(make_finding(
                        title="HTTP redirects to non-HTTPS URL",
                        risk="High",
                        description=(
                            "The HTTP version of the site redirects to a non-HTTPS "
                            "location. Users may be served content over plaintext."
                        ),
                        remediation="Ensure HTTP always redirects to HTTPS.",
                        details={"redirect_location": location},
                    ))
            else:
                findings.append(make_finding(
                    title="HTTP version accessible without redirect",
                    risk="High",
                    description=(
                        "The site serves content over HTTP without redirecting to "
                        "HTTPS, exposing all traffic to interception and MITM attacks."
                    ),
                    remediation=(
                        "Force HTTPS for all requests. For Apache: add "
                        "`RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]` "
                        "in .htaccess. Enable HSTS after testing redirects."
                    ),
                    details={"http_url": http_url,
                             "status_code": http_resp.status_code},
                ))

    elif parsed.scheme == "http":
        findings.append(make_finding(
            title="Site is not using HTTPS",
            risk="Critical",
            description=(
                "The target is accessed over plaintext HTTP. All data including "
                "login credentials, session cookies, and content is transmitted "
                "unencrypted and is trivially interceptable."
            ),
            remediation=(
                "Install an SSL/TLS certificate immediately. Let's Encrypt provides "
                "free certificates via Certbot. Most managed WordPress hosts offer "
                "one-click SSL. After installing, force all traffic to HTTPS."
            ),
        ))

    # ── 2. SSL certificate basics ──────────────────────────────────────────
    if parsed.scheme == "https":
        ssl_findings = _check_ssl_certificate(parsed.netloc)
        findings.extend(ssl_findings)

    return findings


def _check_ssl_certificate(host: str) -> List[Dict]:
    """Attempt a basic SSL handshake and report obvious issues."""
    findings = []
    port = 443

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                proto = ssock.version()

                # Check for old TLS protocols
                if proto in ("TLSv1", "TLSv1.1", "SSLv2", "SSLv3"):
                    findings.append(make_finding(
                        title=f"Weak TLS protocol in use: {proto}",
                        risk="High",
                        description=(
                            f"The server negotiated {proto}, which is deprecated "
                            "and vulnerable to BEAST, POODLE, and other attacks."
                        ),
                        remediation=(
                            "Configure the server to support TLS 1.2 and TLS 1.3 only. "
                            "Disable TLS 1.0 and TLS 1.1 in your web server configuration."
                        ),
                        details={"tls_version": proto},
                    ))
                logger.info("TLS version: %s", proto)

    except ssl.SSLCertVerificationError as e:
        findings.append(make_finding(
            title="SSL certificate verification failed",
            risk="High",
            description=(
                f"The SSL certificate is invalid or untrusted: {e}. "
                "Users' browsers will display security warnings."
            ),
            remediation=(
                "Install a valid, trusted SSL certificate. Use Let's Encrypt "
                "for free, trusted certificates."
            ),
            details={"error": str(e)},
        ))
    except ssl.SSLError as e:
        findings.append(make_finding(
            title="SSL/TLS error during handshake",
            risk="Medium",
            description=f"SSL handshake error: {e}",
            remediation="Review your SSL/TLS configuration for errors.",
            details={"error": str(e)},
        ))
    except (socket.timeout, ConnectionRefusedError, OSError) as e:
        logger.debug("SSL check socket error: %s", e)

    return findings


def _validate_csp(csp_value: str, base_url: str) -> List[Dict]:
    """Flag obviously weak CSP directives."""
    findings = []
    csp_lower = csp_value.lower()

    weak_patterns = [
        ("'unsafe-inline'",  "CSP allows inline scripts",
         "CSP contains 'unsafe-inline' for scripts, which largely negates XSS protection."),
        ("'unsafe-eval'",    "CSP allows eval()",
         "CSP contains 'unsafe-eval', allowing use of eval() which is a common XSS vector."),
        ("* ",               "CSP wildcard source",
         "CSP uses a wildcard (*) source, allowing resources from any origin."),
    ]

    for pattern, title, description in weak_patterns:
        if pattern in csp_lower:
            findings.append(make_finding(
                title=title,
                risk="Medium",
                description=description,
                remediation=(
                    "Tighten the CSP directive. Use nonces or hashes instead of "
                    "'unsafe-inline'. Avoid wildcard sources. "
                    "Use https://csp-evaluator.withgoogle.com/ to validate your policy."
                ),
                details={"csp_value": csp_value[:200]},
            ))

    return findings


def _validate_hsts(hsts_value: str) -> List[Dict]:
    """Check HSTS max-age is sufficiently long (≥ 1 year = 31536000)."""
    findings = []
    m = __import__("re").search(r'max-age=(\d+)', hsts_value, __import__("re").I)
    if m:
        max_age = int(m.group(1))
        if max_age < 31536000:
            findings.append(make_finding(
                title="HSTS max-age is too short",
                risk="Low",
                description=(
                    f"Strict-Transport-Security max-age is {max_age} seconds "
                    f"({max_age // 86400} days). Recommended minimum is 31536000 (1 year)."
                ),
                remediation=(
                    "Set `Strict-Transport-Security: max-age=31536000; "
                    "includeSubDomains; preload` in your server configuration."
                ),
                details={"hsts_max_age_seconds": max_age},
            ))
    return findings


def _is_verbose_server_header(value: str) -> bool:
    """Return True if the Server header contains version numbers."""
    import re
    # Matches version patterns like "Apache/2.4.51" or "nginx/1.21.6"
    return bool(re.search(r'/\d+\.\d+', value))


def _check_cookie_security(resp: requests.Response) -> List[Dict]:
    """Inspect Set-Cookie headers for missing security flags."""
    findings = []
    raw_cookies = resp.headers.get("Set-Cookie", "")
    if not raw_cookies:
        return []

    # requests may collapse multiple Set-Cookie headers
    # Parse each cookie
    cookies_raw = []
    for h, v in resp.headers.items():
        if h.lower() == "set-cookie":
            cookies_raw.append(v.lower())

    insecure_cookies = []
    for cookie_str in cookies_raw:
        issues = []
        if "secure" not in cookie_str:
            issues.append("missing Secure flag")
        if "httponly" not in cookie_str:
            issues.append("missing HttpOnly flag")
        if "samesite" not in cookie_str:
            issues.append("missing SameSite attribute")
        if issues:
            insecure_cookies.append({"cookie": cookie_str[:80], "issues": issues})

    if insecure_cookies:
        findings.append(make_finding(
            title="Insecure cookie configuration",
            risk="Medium",
            description=(
                f"{len(insecure_cookies)} cookie(s) are missing security flags. "
                "Missing Secure flag: cookie transmitted over HTTP. "
                "Missing HttpOnly: accessible to JavaScript (XSS risk). "
                "Missing SameSite: vulnerable to CSRF attacks."
            ),
            remediation=(
                "Set all cookies with Secure, HttpOnly, and SameSite=Strict (or Lax). "
                "WordPress session cookies should use: "
                "`@ini_set('session.cookie_secure', 1);` "
                "`@ini_set('session.cookie_httponly', 1);` in wp-config.php. "
                "Use a security plugin or server config to enforce flags globally."
            ),
            details={"insecure_cookies": insecure_cookies[:5]},
        ))

    return findings


def run_all_header_checks(session: requests.Session, base_url: str,
                           rate_limiter=None) -> Dict[str, Any]:
    """Run all header and SSL checks, return aggregated results."""
    findings: List[Dict] = []

    logger.info("Analysing security headers…")
    findings.extend(check_security_headers(session, base_url, rate_limiter))

    logger.info("Checking HTTPS enforcement and SSL/TLS…")
    findings.extend(check_https(session, base_url, rate_limiter))

    return {"findings": findings}
